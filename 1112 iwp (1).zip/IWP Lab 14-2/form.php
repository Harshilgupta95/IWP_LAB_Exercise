<!DOCTYPE html>
<html>
<head>
	<title>From</title>
	<style type="text/css">
		h1{
			text-align: center;
		}
		table{
			padding: 30px;
		}
		th{
			padding: 20px;
		}
		td{
			padding: 20px;
		}

	</style>
</head>
<body>
	<h1>Registered Successfully</h1>

	<table>
		<tr>
			<th>Name:</th>
			<td>
				<?php echo $_POST['name'];?>
			</td>
		</tr>
		<tr>
			<th>Type:</th>
			<td>
				<?php echo $_POST['type1'];?>
			</td>
		</tr>
		<tr>
			<th>Paid In</th>
			<td><?php echo $_POST['rfee'];?></td>
		</tr>
		<tr>
			<th>Amount:</th>
			<td><?php echo $_POST['amount'];?></td>
		</tr>
		<tr>
			<th>Payment Method</th>
			<td><?php echo $_POST['pmethod'];?></td>
		</tr>
		<tr>
			<th>Card Number:</th>
			<td><?php echo $_POST['cnumber'];?></td>
		</tr>
		<tr>
			<th>Expiry Date:</th>
			<td><?php echo $_POST['date1'];?></td>
		</tr>
		<tr>
			<th>CVV:</th>
			<td><?php echo $_POST['cvv'];?></td>
		</tr>
		<tr>
			<th>Hotel Service Select:</th>
			<td><?php
			if(!empty($_POST['service'])){ foreach ($_POST['service'] as $selected){
				echo $selected."<br>"; 
				# code...
			}
			}
			?></td>
		</tr>

</table>

</body>
</html>
