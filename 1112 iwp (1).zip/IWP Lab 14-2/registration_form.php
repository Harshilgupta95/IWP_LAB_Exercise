<!DOCTYPE html>
<html>
<head>
	<title>Internatonal Seminar Registration Form</title>
	<style type="text/css">
		.heading{
			text-align: center;
		}
		table{
			padding: 30px;
		}
		th{
			padding: 20px;
		}
		td{
			padding: 20px;
		}
	</style>
</head>
<body>
<div class="heading">
<h1>Internation Seminar</h1>
<p>Registation Form</p>

</div>
<div class="form">
	<form method="post" onsubmit="return f()" name="regfrom" action="form.php">
		<table>
			<tr>
				<th>Name: </th>
				<td><input type="text" name="name" required></td>
			</tr>
			<tr>
				<th>Type:</th>
				<td>
				<select name="type1">
					<option value="Student">Student</option>
					<option value="Faculty">Faculty</option>
					<option value="profectional">Profectional</option>
					<option value="reprenstative">Representatives</option>
				</select>
				</td>
			</tr>
			<tr>
				<th>Registation Fee</th>
				<td>Dollar<input type="radio" name="rfee" value="Dollar" checked></td>
				<td><input type="radio" name="rfee" value="Rupee">Rupee</td>
			</tr>
			<tr>
				<th>Amount</th>
				<td><input id="id1" type="number" name="amount"></td>
			</tr>
			<tr>
				<th>Payment Method</th>
				<td><input type="radio" name="pmethod" value="Credit Card" checked> Credit Card</td>
				<td><input type="radio" name="pmethod" value="Debit Card"> Debit Card</td>
				<td><input type="radio" name="pmethod" value="Demand Draft"> Demand Draft</td>
			</tr>
			<tr>
				<th>Card Number:</th>
				<td><input type="number" name="cnumber" id="cnumber"></td>
			</tr>
			<tr>
				<th>Expiry Date:</th>
				<td><input type="date" name="date1" id="date"></td>
			</tr>
			<tr>
				<th>CVV:</th>
				<td><input type="number" name="cvv" id="cvv"></td>
			</tr>
			<tr>
				<th>Hotel Service</th>
				<td>
					<input type="checkbox" name="service[]" value="WIFI">WIFI<br>
					<input type="checkbox" name="service[]" value="FAX">FAX<br>
					<input type="checkbox" name="service[]" value="Television">Television<br>
					<input type="checkbox" name="service[]"  value="Laundry">Laundary<br>
					<input type="checkbox" name="service[]" value="AC">AC<br>
					<input type="checkbox" name="service[]" value="Locker">Locker<br>
					<input type="checkbox" name="service[]" value="Breakfast">Breakfast<br>
					<input type="checkbox" name="service[]" value="refrigerator">Refrigerator
				</td>
			</tr>
			<tr>
				<th>
				<input type="submit" name="submit">
			</th>
			</tr>
			
	</form>
	</table>
	<script type="text/javascript">
		function f(){
			var x = document.getElementById('id1').value;
			var y = document.getElementById('cnumber').value;
			var z = document.getElementById('date').value;
			var c = document.getElementById('cvv').value;
			if (x== "") {
				alert("Please Enter Amount");
				return false;
			}
			else if(y == "" || y>999999999999999){
				alert("Invalid Card Number");
				return false;
			}
			else if(c == "" || c > 1000){
				alert("Invalid CVV")
				return false;
			}
			else{
				alert("Sucessfully Submited")
			}
		}
	</script>
</div>
</body>
</html>